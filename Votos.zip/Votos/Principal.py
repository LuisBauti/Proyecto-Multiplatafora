# -*-encoding: utf-8 -*-
##############################################################################
# Programa: Elecciones                                                       #
# Proposito: Conteo de votos                                                 #
# Autores: Owen Ariel Valle, Patrick David Soto, Luis Consuegra,             #
#          Klisban Rodiney Morales                                           #
# Fecha: 17/04/2020                                                          #
#               PROYECTO FINAL                                               #
##############################################################################

import Setup
#Importamos todos los metodos de la carpeta metodos.
from Metodos import Metodo_ingreso_usuario, Metodo_ingreso_municipio, Metodos_ingreso_candidato, Metodos_principal, Metodos_reporte
from Pantallas import Principal, Limpiar_interfaz
from PySide2.QtWidgets import QMainWindow, QFileDialog, QMessageBox
from PySide2.QtGui import QPixmap

# Creamos la clase principal
class Ventana_principal(QMainWindow):
    def __init__(self, parent = None, *info_usuario):
        super(Ventana_principal, self).__init__(parent)
        # Cargamos el archivo de la interfaz grafica
        self.ui = Principal.Ui_MainWindow()
        self.ui.setupUi(self)

        # Verificamos los permisos para ver que opciones deben estar disponible
        # Si es Administrador permite acceder a toda la informacion.
        # Si es Usuario permite solo acceder a votar.
        if info_usuario[0][2] == 1:
            pass
        else:
            self.ui.Barra_Configuracion.setDisabled(1)
            self.ui.Barra_Reportes.setDisabled(1)
        self.ui.stackedWidget_principal.setCurrentIndex(0)

        # LLenado de combos.
        self.ui.combo_municipio.clear()
        Metodos_principal.llenar_combo_municipio(self)

        # Conectamos los elementos de la barra para seleccionar el stackWidget(Barra lateral Izquierda)
        self.ui.Barra_Configuracion.triggered.connect(self.configuracion)
        self.ui.Barra_Registro.triggered.connect(self.registro)
        self.ui.Barra_Salir.triggered.connect(self.logueo)
        self.ui.Barra_Reportes.triggered.connect(self.reportes)

        # Conectamos la elementos graficos de de nuevo ingreso de usuario(Login principal)
        self.ui.nuevo_aceptar.clicked.connect(self.nuevo_ingreso)
        self.ui.nuevo_cancelar.clicked.connect(self.nuevo_cancelar)

        # Conectamos los elementos graficos de ingreso de municipio(Pantalla municipios)
        self.ui.agregar_municipio.clicked.connect(self.ingreso_municipio)

        # Conectamos los metodos para cuando cambia el focus del tabwidget(Tabulador)
        self.ui.tab_ajustes.currentChanged.connect(self.ajustes_municipio)

        # Conectamos los metodos cuando cambien el combobox candidatos
        # Que se cargue el candidato de cada municipio.
        self.ui.combo_municipios.currentIndexChanged.connect(self.mostrar_candidato)

        # Conectamos los metodos graficos de ingreso candidatos(Pantalla Candidatos)
        self.ui.candidato_ingreso.clicked.connect(self.nuevo_candidato)

        # Conectamos los metodos para agregar informacion a la Base de Datos
        self.ui.ine_frontal.clicked.connect(self.foto_delantera)
        self.ui.ine_trasera.clicked.connect(self.foto_trasera)
        self.ui.ingreso_aceptar.clicked.connect(self.agregar_info)
        self.ui.combo_municipio.currentIndexChanged.connect(self.municipio_candidatos)
        self.ui.ingreso_cancelar.clicked.connect(self.limpiar_ingreso_informacion)

        # Conectamos los metodos para generar el reporte de cuantas personas han votado
        self.ui.combo_reporte_municipio.currentIndexChanged.connect(self.reporte_candidato)
        self.ui.reporte_generar.clicked.connect(self.generar_reporte)

    
    # Funcion para generar el reporte de los votantes
    def generar_reporte(self):
        Metodos_reporte.reporte_generar(self)

    # Funcion para generar el reporte de candidato
    def reporte_candidato(self):
        Metodos_reporte.combo_reporte_candidato(self)

     # Mostrar reportes
    def reportes(self):
        self.ui.stackedWidget_principal.setCurrentIndex(1)
        Metodos_reporte.combo_reporte_municipio(self)

     #Funcion para limpiar la parte del registro a la hora de registrar
    def limpiar_ingreso_informacion(self):
        Limpiar_interfaz.limpieza_ingreso_informacion(self)

    # Funcion para verificar el municipio de donde votan por el candidato
    def municipio_candidatos(self):
        Metodos_principal.llenar_combo_candidato(self)

    # Funcion para agregar la informacion del votante
    def agregar_info(self):
        try:
            Metodos_principal.nuevo_ingreso(self, self.dir_delantera, self.dir_trasera)
        except AttributeError:
            QMessageBox.about(self,"INFORMACION", "No has seleccionado las imagenes" )

    # Funcion para extraer imagenes desde la PC
    def foto_trasera(self):
        self.dir_trasera, _ = QFileDialog.getOpenFileName(self, 'Seleccionar Imagen', '~/Proyectos/Votos', 'Imagen(*.jpg)')
        imagen = QPixmap(self.dir_trasera)
        self.ui.foto_trasera.setPixmap(imagen)

    # Funcion para extraer la imagen desde la PC
    def foto_delantera(self):
        self.dir_delantera, _ = QFileDialog.getOpenFileName(self, 'Seleccionar Imagen', '~/Proyectos/Votos', 'Imagen(*.jpg)')
        imagen = QPixmap(self.dir_delantera)
        self.ui.foto_delantera.setPixmap(imagen)

    # Funcion para el login principal
    def logueo(self):
        self.close()
        ventana1 = Setup.Lanzador(self)
        ventana1.show()

    # Funcion para mostrar el candidato(Buscar el candidato)
    def mostrar_candidato(self):
        Metodos_ingreso_candidato.buscar_candidato(self)

    # Funcion para agregar un nuevo candidato
    def nuevo_candidato(self):
        Metodos_ingreso_candidato.agregar_candidato(self)

    # Funcion para la pantalla de municipio(Ingresar, Buscar, Limpiar, Candidato)
    def ajustes_municipio(self):
        tab_focus = self.ui.tab_ajustes.currentIndex()
        if tab_focus == 0:
            Limpiar_interfaz.limpieza_ingreso_nuevo_usuario(self)
            self.ui.combo_municipio.setCurrentIndex(0)
        elif tab_focus == 1:
            Metodo_ingreso_municipio.obtener_municipio(self)
            self.ui.lista_municipio.setDisabled(True)
        elif tab_focus == 2:
            Metodos_ingreso_candidato.llenado_combobox(self)
            self.ui.lista_candidato.setDisabled(True)

    # Funcion para ingreso de municipio.     
    def ingreso_municipio(self):
        Metodo_ingreso_municipio.ingreso_municipio(self)
        self.ui.nombre_municipio.setText("")
        self.ajustes_municipio()

    # Funcion para cancelar
    def nuevo_cancelar(self):
        Limpiar_interfaz.limpieza_ingreso_nuevo_usuario(self)

    # Funcion para ingresar un nuevo usuario
    def nuevo_ingreso(self):
        Metodo_ingreso_usuario.nuevo_ingreso(self)
        Limpiar_interfaz.limpieza_ingreso_nuevo_usuario(self)

    # Funcion para la barra registro
    def registro(self):
        self.ui.stackedWidget_principal.setCurrentIndex(0)

    # Funcion para la configuracion la barra
    def configuracion(self):
        self.ui.stackedWidget_principal.setCurrentIndex(2)
        self.ui.tab_ajustes.setCurrentIndex(0)
        Limpiar_interfaz.limpieza_ingreso_nuevo_usuario(self)

    def salir(self):
        self.close()